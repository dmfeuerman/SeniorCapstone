
let item = "";

function getItem(){
    return item;
}

export class setItem {

    static set(newItem) {
        item = newItem;
        console.log(item);
    }

    static getItem(){
        return item;
    }
}
