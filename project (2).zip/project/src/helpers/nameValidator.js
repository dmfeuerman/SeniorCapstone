export function nameValidator(name) {
  if (!name) return "Name can't be empty."
  return ''
}
